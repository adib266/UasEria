package com.example.MyUasRahma.Model

class Model (
    val handphone: List<Data>
) {
    data class Data (val nama:String?, val harga:String?)
}