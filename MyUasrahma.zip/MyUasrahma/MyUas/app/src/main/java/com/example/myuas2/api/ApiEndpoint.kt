package com.example.MyUasRahma.api

import com.example.MyUasRahma.Model.Model
import retrofit2.Call
import retrofit2.http.GET

interface ApiEndpoint {
    @GET("data.php")
    fun data() : Call<Model>
}